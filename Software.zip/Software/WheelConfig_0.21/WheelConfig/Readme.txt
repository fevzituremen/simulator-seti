------------------------------------------------------------------------------------------

	Race Pack

	Copyright Ai-Wave Development & Game Seed 2007-2012

	Support e-mail :  support@gameseed.fr

------------------------------------------------------------------------------------------

Warning : 

- To do a screenshot, use the "F11" key, rather then the "Print Screen" key. Screenshots are stored in the "Screenshots" folder where you installed the game.

------------------------------------------------------------------------------------------
1/ Installation
------------------------------------------------------------------------------------------

Operating System : Windows XP

You'll need to have DirectX9.0c installed to run the game.
A recent version of DirectX9 is included with the installer.

Minimum Configuration :

2.4 Ghz CPU + 1 Gb ram, 512 MB DirectX 8 Graphic card 


Recomended Configuration :

3.5 Ghz CPU + 2 Gb ram, Graphic card  : Geforce GTX 680
Force feedback steering wheel

